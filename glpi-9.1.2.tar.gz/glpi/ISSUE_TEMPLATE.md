Dear GLPi user.

BEFORE SUBMITTING YOUR ISSUE, please make sure to read and follow these steps :

* We don't support community plugins. Contact directly their authors, or use the community forum : http://forum.glpi-project.org.
* For feature requests or enhancements, use the suggest dedicated site (http://suggest.glpi-project.org ). We check it very often.
* We prefer to keep this tracker in ENGLISH. If you want support in your language, the community forum (http://forum.glpi-project.org) is the best place.
* For bug reports, you can open an issue here. Add to your content a full description of your glpi setup (you can find it in Setup > General menu, System tab).
* Provide us steps to reproduce your issue.
* Delete this text to submit your issue.

The GLPi team.
